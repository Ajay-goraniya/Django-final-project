#!/bin/sh
# How the live Zurich maker probe is started. The four credentials are sourced into THIS CHILD ONLY
# and are never written anywhere by the probe. ENABLED must exist and contain "1" first.
set -e
test -s /home/ubuntu/maker_probe/ENABLED || { echo "ENABLED flag missing - refusing"; exit 1; }
cd /home/ubuntu/pm_paper_zurich
set -a; . /home/ubuntu/polymarket_v12/deploy.env; set +a
nohup ./.venv/bin/python maker_probe.py >> /home/ubuntu/maker_probe/live8.log 2>&1 &
echo $! > /home/ubuntu/maker_probe/pid.txt
echo "started pid $(cat /home/ubuntu/maker_probe/pid.txt)"
# Stop: kill that pid, but FIRST confirm no order is resting, or it is orphaned at the venue.
# Safest moment is before second 60 of a candle, when nothing can be resting.
