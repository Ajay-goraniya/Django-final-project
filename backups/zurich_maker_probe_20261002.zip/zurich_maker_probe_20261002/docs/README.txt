ZURICH MAKER PROBE - BACKUP OF EXACTLY WHAT IS RUNNING, 2026-10-02 12:3x UTC
=============================================================================
Code and documents only. NO DATABASES and NO SECRETS are in this archive - see SECRETS below.

THE RULE, AS IT IS LIVE RIGHT NOW
  One separate process. It posts POST-ONLY BUY orders and never takes.
  WINDOW      seconds 60-120 of the 5-minute candle. SEC_HI is also the hard cancel, so a resting
              order is pulled at 121. Changed from 60-180 on 10-02 11:50 UTC on the owner's written
              confirmation ("Cool change Zurich maker to this"); before that it was 60-180.
  CALM GATE   FavBrain.vol_before_open(epoch) < 0.304, i.e. the std of 1 s Binance log returns over
              the 300 s BEFORE the candle opened, x1e4. Computed once per candle, read at post time
              only. It cannot change inside the candle and it is NOT re-checked while resting.
  FAVOURITE   the side whose best BID is inside 0.60-0.80. We post 5 shares at that bid, post-only.
  CANCELS     exactly two: Binance moves >= 2 bps AGAINST our side over 1 s, or the second leaves
              60-120. Nothing about the Polymarket book pulls a resting order.
  CEILINGS    at most 3 posts per candle; one open order at a time; one fill per candle, where a
              fill under 1.0 share is dust and does not count as the candle's fill.
  HOLD        to settlement, always. There is no stop loss and no take profit - 45 exit cells were
              tested on the live fills and not one beat holding (PROBE_EXIT_GRID.txt).
  GRADING     the venue's own resolution from the gamma mirror, never a Binance close.
  STOPS       -$10 on the UTC day and -$20 lifetime, both summed from the fills table. FIXED stake
              of 5 shares; there is no Kelly and no dynamic staking.

FILES
  probe/maker_probe.py        the probe. Everything above lives here.
  probe/poly_fav.py           the frozen calm gate (FavBrain, VOL_CUT). stdlib only.
  probe/poly_live.py          the venue client wrapper, imported lazily when going live.
  probe/poly_core.py          fee/error helpers used by poly_live, including the log redactor.
  probe/test_maker_probe.py   135 tests. Run from the probe directory: python -m pytest -q
  ops/grade.py                cron, every 2 min: attaches the venue outcome to unsettled fills and
                              writes grade.heartbeat. The stops are blind to an ungraded fill, so
                              this is not optional.
  ops/watch.py                the alert watcher. Exits on the first alertable event.
  ops/m21_watch.py            cron, every 5 min: latches the 200-distinct-graded-candle mark.
  ops/verify_fills.py         venue cross-check of fills (needs the env vars; see SECRETS).
  ops/maker_60.py             the milestone report.
  ops/pip-freeze.txt          the venv as it is.
  ops/crontab-probe-lines.txt the two cron lines that belong to the probe, verbatim.
  ops/launch.sh               how the live process is started.
  docs/MAKER_PROBE.txt        the full running record: every incident, fix and owner decision.
  docs/deploy.env.example     KEY NAMES ONLY, every credential value empty.

THE ENABLE FLAG
  The probe refuses to go live unless /home/ubuntu/maker_probe/ENABLED exists and contains "1",
  and it is started without --dry-run. Deleting that file stops it posting on its next pass; it
  does NOT cancel an order already resting, so delete it and then confirm no open order remains.

SECRETS - WHAT IS NOT HERE AND WHERE IT GOES
  This archive contains no keys, no passphrases, no wallet addresses and no .env file. It was
  grepped for 0x[0-9a-f]{64}, "secret", "passphrase" and "private" before packaging; the only hits
  were environment-variable NAMES and the redaction helper in poly_core.py, which exists to strip
  such values out of logs.
  The live process reads four variables from its environment and nothing else:
    POLYMARKET_PRIVATE_KEY, POLYMARKET_WALLET_ADDRESS, RELAYER_API_KEY, RELAYER_API_KEY_ADDRESS
  On this box they live in /home/ubuntu/polymarket_v12/deploy.env, mode 600, never committed, and
  they are sourced into the child process only at launch. To rebuild elsewhere: copy
  deploy.env.example to deploy.env, fill in those four, chmod 600, and launch as in ops/launch.sh.
  DASHBOARD_PASSWORD is used only by the read-only status page, which is not part of this archive.

WHAT IS DELIBERATELY ABSENT
  No databases: maker_probe.sqlite3 (orders, fills, decisions), the gamma mirror, bn_flow and the
  public tape are all excluded, so this archive cannot reconstruct the ledger - only the rule.
  No M19 paper shadow: that is a separate paper-only experiment and places no orders.
